﻿using System;

namespace SOLID_OCP     //  OPEN CLOSE PRINCIPLE
{
    class Program
    {
        static void Main(string[] args)
        { 
            double amount = 10000;

            Invoice invoice = new Invoice();
            amount = invoice.GetInvoiceDiscount(amount);
            Console.WriteLine($"Invoice Amount: {amount}");

            Invoice fInvoice = new FinalInvoice();
            amount = fInvoice.GetInvoiceDiscount(amount);
            Console.WriteLine($"Final Invoice Amount: {amount}");

            Invoice pInvoice = new ProposedInvoice();
            amount = pInvoice.GetInvoiceDiscount(amount);
            Console.WriteLine($"Proposed Invoice Amount: {amount}");

            Invoice rInvoice = new RecurringInvoice();
            amount = rInvoice.GetInvoiceDiscount(amount);
            Console.WriteLine($"Recurring Invoice Amount: {amount}");

            Console.ReadKey();
        }
    }
}
