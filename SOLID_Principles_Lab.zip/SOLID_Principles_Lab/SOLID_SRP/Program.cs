﻿using System;

namespace SOLID_SRP     // SINGLE RESPONSIBILITY PRINCIPLE
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee emp = new Employee("Atif");
            emp.AddEmployee();
            Console.WriteLine($"{emp._name} Added as Employee");

            EmailSender emailSender = new EmailSender();
            emailSender.SendEmail();
            
        }
    }
}
