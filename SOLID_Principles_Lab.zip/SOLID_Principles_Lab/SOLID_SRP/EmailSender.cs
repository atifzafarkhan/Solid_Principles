﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SOLID_SRP
{
    public class EmailSender
    {
        public void SendEmail()
        {
            Console.WriteLine("and E-mal has been sent.");
        }
    }
}
