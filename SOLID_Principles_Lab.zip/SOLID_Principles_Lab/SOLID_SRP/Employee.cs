﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SOLID_SRP
{
    public class Employee
    {
        public readonly string _name = null;
        public Employee(string name)
        {
            _name = name;
        }
        public string AddEmployee()
        {
            return _name;
        }
        public string UpdateEmployee()
        {
            return _name;
        }
        public string DeleteEmployee()
        {
            return _name;
        }
        public string GetEmployee()
        {
            return _name;
        }
    }
}
