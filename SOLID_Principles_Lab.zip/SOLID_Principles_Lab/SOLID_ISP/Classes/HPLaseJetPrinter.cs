﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SOLID_ISP
{
    public class HPLaseJetPrinter : IPrinterTasks, IFaxTasks, IPrintDuplexTasks
    {
        public void Print(string printContent)
        {
            Console.WriteLine($"HPLaseJetPrinter has been done printing {printContent}");
        }
        public void Scan(string scanContent)
        {
            Console.WriteLine($"HPLaseJetPrinter has been done scanning {scanContent}");
        }
        public void Fax(string content)
        {
            Console.WriteLine($"HPLaseJetPrinter has been done fax {content}");
        }     

        public void PrintDuplex(string content)
        {
            Console.WriteLine($"HPLaseJetPrinter has been done duplex {content}");
        }

       
    }
}
