﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SOLID_ISP
{
    public class LiquidInkjetPrinter : IPrinterTasks
    {
        public void Print(string printContent)
        {
            Console.WriteLine($"LiquidInkjetPrinter has been done printing {printContent}");
        }

        public void Scan(string scanContent)
        {
            Console.WriteLine($"LiquidInkjetPrinter has been done scanning {scanContent}");
        }
    }
}
