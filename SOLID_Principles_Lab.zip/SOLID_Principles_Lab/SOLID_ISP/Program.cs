﻿using System;

namespace SOLID_ISP
{
    class Program
    {
        static void Main(string[] args)
        {
            HPLaseJetPrinter hPLaseJetPrinter = new HPLaseJetPrinter();
            hPLaseJetPrinter.Print("Documents");
            hPLaseJetPrinter.Scan("PDF");
            hPLaseJetPrinter.Fax("Proposal");
            hPLaseJetPrinter.PrintDuplex("Banners");

            LiquidInkjetPrinter liquidInkjetPrinter = new LiquidInkjetPrinter();
            liquidInkjetPrinter.Print("Notes");
            liquidInkjetPrinter.Scan("Exam Materials");

            Console.ReadKey();
        }
    }
}
