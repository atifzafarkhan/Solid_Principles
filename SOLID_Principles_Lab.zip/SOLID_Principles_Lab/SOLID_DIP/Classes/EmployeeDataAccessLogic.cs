﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SOLID_DIP
{
    // LLM
    public class EmployeeDataAccessLogic : IEmployeeDataAccessLogic
    {
        public Employee GetEmployeeDetails(int id)
        {
            Employee emp = new Employee()
            {
                ID = id,
                Name = "Atif",
                Department = "IT",
                Salary = 100000
            };
            return emp;
        }

        public void AddEmployee()
        {
            
        }

        public void DeleteEmployee()
        {
            
        }
    }
}
