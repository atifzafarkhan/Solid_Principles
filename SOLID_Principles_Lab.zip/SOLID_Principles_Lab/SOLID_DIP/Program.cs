﻿using System;

namespace SOLID_DIP
{
    class Program
    {
        static void Main(string[] args)
        {
            EmployeeBusinessLogic employeeBusinessLogic = new EmployeeBusinessLogic();
            Employee emp = employeeBusinessLogic.GetEmployeeDetails(100);
            Console.Write($"{emp.ID}, {emp.Name}, {emp.Department}, {emp.Salary}");
            Console.ReadKey();
        }
    }
}
