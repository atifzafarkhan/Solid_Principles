﻿using System;

namespace SOLID_LSP
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Implemented using Interface
            IFruit fruit = new Apple();
            Console.WriteLine($"This fruit color is {fruit.GetColor()}");

            fruit = new Orange();
            Console.WriteLine($"This fruit color is {fruit.GetColor()}");
            #endregion

            #region Implemented using Abstract Class
            Fruit _fruit = new Apple();
            Console.WriteLine($"Some Apples are {_fruit.GetFruitColor()}");

            _fruit = new Orange();
            Console.WriteLine($"Some Oranges are {_fruit.GetFruitColor()}");
            #endregion

            Console.ReadKey();
        }
    }
}
