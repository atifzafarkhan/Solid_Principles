﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SOLID_LSP
{
    public class Apple : Fruit, IFruit
    {
        public string GetColor()
        {
            return "Red";
        }

        public override string GetFruitColor()
        {
            return "Green";
        }
    }
}
