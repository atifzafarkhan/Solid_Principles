﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SOLID_LSP
{
    public class Orange : Fruit, IFruit
    {
        public string GetColor()
        {
            return "Orange";
        }
        public override string GetFruitColor()
        {
            return "Light Orange";
        }
    }
}
